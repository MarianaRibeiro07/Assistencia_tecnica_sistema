<?php

// Inicia a sessão para acessar os dados do usuário logado
session_start();

// Verifica se o usuário está autenticado; caso contrário, redireciona para a página de login
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit();
}

// Verifica o tempo de expiração da sessão: se ficou mais de 30 minutos sem usar o sistema,
// encerra a sessão e volta para o login avisando que expirou
if (time() - $_SESSION['ultimo_acesso'] > 30 * 60) {
    session_destroy();
    header('Location: login.php?expirou=1');
    exit();
}

// Ainda está no prazo: renova o horário do último acesso
$_SESSION['ultimo_acesso'] = time();

// Inclui o arquivo de configuração para estabelecer a conexão com a base de dados
include 'config.php';

// Recebe o ID do carro a ser editado via parâmetro GET na URL; se não informado, assume 0
$id = $_GET['id'] ?? 0;

// Prepara e executa uma consulta para buscar os dados do carro com o ID informado
$sql = "SELECT * FROM dispositivos WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
$dispositivo = $res->fetch_assoc();

// Se não encontrou o dispositivo, exibe mensagem e termina a execução
if (!$dispositivo) {
    echo "Dispositivo não encontrado.";
    exit();
}

// Processa o formulário quando enviado via POST para atualizar o dispositivo
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Coleta os dados atualizados do formulário
    $cliente_id = $_POST['cliente_id'];   // (clínica: $tutor_id = $_POST['tutor_id'];)
    $modelo = $_POST['modelo'];     // (clínica: $nome = $_POST['nome'];)
    $marca = $_POST['marca'];       // (clínica: $especie = $_POST['especie'];)
    $placa = $_POST['placa'];       // (clínica: $raca = $_POST['raca'];)
    $cor = $_POST['cor'];           // (clínica: fica igual)
    $ano = $_POST['ano'];           // (clínica: $data_nascimento = $_POST['data_nascimento'];)

    // Validação simples: cliente, modelo e marca são obrigatórios
    if (!$cliente_id || !$modelo || !$marca) {
        echo "Cliente, modelo e marca são obrigatórios.";
    } else {
        // Atualiza os dados do dispositivo no banco de dados
        $sql = "UPDATE dispositivos SET cliente_id=?, modelo=?, marca=?, placa=?, cor=?, ano=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("issssii", $cliente_id, $modelo, $marca, $placa, $cor, $ano, $id);
        $stmt->execute();

        // Redireciona o usuário de volta para a lista de dispositivos após atualizar
        
        header("Location: dispositivos.php");
        exit();
    }
}

// Busca todos os clientes para preencher o select (permite trocar o cliente do dispositivo)
$clientes = $conn->query("SELECT id, nome FROM cliente ORDER BY nome");
?>
<!-- Folha de estilo padrão do sistema (todas as telas usam o mesmo arquivo css/style.css) -->
<link rel="stylesheet" href="css/style.css">

<h2>Editar Dispositivo</h2>

<!-- Formulário para edição do dispositivo com dados já preenchidos -->
<form method="post">
    <select name="cliente_id" required>
        <!-- Deixa selecionado o cliente atual do dispositivo -->
        <?php while ($d = $clientes->fetch_assoc()): ?>
            <option value="<?= $d['id'] ?>" <?= $d['id'] == $dispositivo['cliente_id'] ? 'selected' : '' ?>><?= htmlspecialchars($d['nome']) ?></option>
        <?php endwhile; ?>
    </select>
    <input name="modelo" placeholder="Modelo" value="<?= htmlspecialchars($dispositivo['modelo']) ?>" required>
    <input name="marca" placeholder="Marca" value="<?= htmlspecialchars($dispositivo['marca']) ?>" required>
    <input name="placa" placeholder="Placa" value="<?= htmlspecialchars($dispositivo['placa'] ?? '') ?>">
    <input name="cor" placeholder="Cor" value="<?= htmlspecialchars($dispositivo['cor'] ?? '') ?>">
    <input type="number" name="ano" required placeholder="Ano" value="<?= htmlspecialchars($dispositivo['ano'] ?? '') ?>">
    <button>Salvar</button>
</form>

<!-- Link para voltar à página de listagem de dispositivos -->
<a href="dispositivos.php">Voltar</a>
